# SPICE simulation in Python

This assignment gives details on implementing a basic SPICE simulator for electronic circuits in Python.  Detailed [instructions](docs/INSTRUCTIONS.md) are given in the documentation folder. 
