def evalSpice(filename):
    return ({}, {})
